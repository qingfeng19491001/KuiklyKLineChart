//
// this file is generating by ksp
// please do not modified it!!!
import com.tencent.kuikly.core.manager.BridgeManager
import com.tencent.kuikly.core.nvi.NativeBridge
import kotlin.Unit
import kotlin.js.ExperimentalJsExport
import kotlin.js.JsExport
import kotlin.js.JsName

@JsName(name = "callKotlinMethod_KuiklyKLineChart")
@JsExport
@ExperimentalJsExport
public fun callKotlinMethod_KuiklyKLineChart(): Unit {
}

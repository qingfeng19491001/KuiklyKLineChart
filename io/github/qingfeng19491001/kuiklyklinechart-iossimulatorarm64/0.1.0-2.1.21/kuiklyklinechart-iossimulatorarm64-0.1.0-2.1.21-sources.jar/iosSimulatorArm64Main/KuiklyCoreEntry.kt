//
// this file is generating by ksp
// please do not modified it!!!
import com.tencent.kuikly.core.manager.BridgeManager
import com.tencent.kuikly.core.nvi.NativeBridge
import kotlin.Unit

public object KuiklyCoreEntry_KuiklyKLineChart {
  public fun triggerRegisterPages(): Unit {
  }
}
